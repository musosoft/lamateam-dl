"resources"
{
    "resource/overviews/de_kismayo.txt"  "file"
    "materials/overviews/de_kismayo.vmt" "file"
    "materials/overviews/de_kismayo.vtf" "file"
    "materials/overviews/de_kismayo_radar.vmt"   "file"
    "maps/de_kismayo.nav"    "file"
    "maps/de_kismayo.bsp"    "file"
}