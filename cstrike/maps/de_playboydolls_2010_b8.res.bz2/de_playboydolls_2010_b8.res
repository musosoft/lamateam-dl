"resources"
{
    "resource/overviews/de_playboydolls_2010_b8.txt"  "file"
    "materials/overviews/de_playboydolls_2010_b8.vmt" "file"
    "materials/overviews/de_playboydolls_2010_b8.vtf" "file"
    "materials/overviews/de_playboydolls_2010_b8_radar.vmt"   "file"
    "maps/de_playboydolls_2010_b8.nav"    "file"
    "maps/de_playboydolls_2010_b8.bsp"    "file"
}