"resources"
{
    "resource/overviews/cs_crackhouse_hg_a2.txt"  "file"
    "materials/overviews/cs_crackhouse_hg_a2.vmt" "file"
    "materials/overviews/cs_crackhouse_hg_a2.vtf" "file"
    "materials/overviews/cs_crackhouse_hg_a2_radar.vmt"   "file"
    "maps/cs_crackhouse_hg_a2.nav"    "file"
    "maps/cs_crackhouse_hg_a2.bsp"    "file"
}