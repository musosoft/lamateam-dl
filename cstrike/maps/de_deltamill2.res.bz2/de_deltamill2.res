"resources"
{
    "resource/overviews/de_deltamill2.txt"  "file"
    "materials/overviews/de_deltamill2.vmt" "file"
    "materials/overviews/de_deltamill2.vtf" "file"
    "materials/overviews/de_deltamill2_radar.vmt"   "file"
    "maps/de_deltamill2.nav"    "file"
    "maps/de_deltamill2.bsp"    "file"
}