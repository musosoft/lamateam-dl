"resources"
{
    "resource/overviews/aim_deagle7k.txt"  "file"
    "materials/overviews/aim_deagle7k.vmt" "file"
    "materials/overviews/aim_deagle7k" "file"
    "materials/overviews/aim_deagle7k_radar.vmt"   "file"
    "maps/aim_deagle7k.nav"    "file"
    "maps/aim_deagle7k.bsp"    "file"
}