"resources"
{
    "resource/overviews/fy_snow.txt"  "file"
    "materials/overviews/fy_snow.vmt" "file"
    "materials/overviews/fy_snow" "file"
    "materials/overviews/fy_snow_radar.vmt"   "file"
    "maps/fy_snow.nav"    "file"
    "maps/fy_snow.bsp"    "file"
}