"resources"
{
    "resource/overviews/de_anubis_css.txt"  "file"
    "materials/overviews/de_anubis_css.vmt" "file"
    "materials/overviews/de_anubis_css.vtf" "file"
    "materials/overviews/de_anubis_css_radar.vmt"   "file"
    "maps/de_anubis_css.nav"    "file"
    "maps/de_anubis_css.bsp"    "file"
}