"resources"
{
    "resource/overviews/awp_rooftops_css.txt"  "file"
    "materials/overviews/awp_rooftops_css.vmt" "file"
    "materials/overviews/awp_rooftops_css.vtf" "file"
    "materials/overviews/awp_rooftops_css_radar.vmt"   "file"
    "maps/awp_rooftops_css.nav"    "file"
    "maps/awp_rooftops_css.bsp"    "file"
}