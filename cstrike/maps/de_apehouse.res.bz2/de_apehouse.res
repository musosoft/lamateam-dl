"resources"
{
    "maps/de_apehouse.bsp" "file"
    "maps/de_apehouse.nav" "file"
    "materials/overviews/de_apehouse_radar.vmt"   "file"
    "materials/overviews/de_apehouse.vmt" "file"
    "materials/overviews/de_apehouse.vtf" "file"
    "resource/overviews/de_apehouse.txt"  "file"
    "sound/homicidalape/Ghostwriter.wav" "file"
    "sound/homicidalape/One Heavy February.wav" "file"
    "sound/homicidalape/schmaltzherring1.wav" "file"
    "sound/homicidalape/Sweet.wav" "file"
} 