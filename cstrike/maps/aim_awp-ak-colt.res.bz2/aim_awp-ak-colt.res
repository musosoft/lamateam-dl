"resources"
{
    "resource/overviews/aim_awp-ak-colt.txt"  "file"
    "materials/overviews/aim_awp-ak-colt.vmt" "file"
    "materials/overviews/aim_awp-ak-colt" "file"
    "materials/overviews/aim_awp-ak-colt_radar.vmt"   "file"
    "maps/aim_awp-ak-colt.nav"    "file"
    "maps/aim_awp-ak-colt.bsp"    "file"
}