"resources"
{
    "resource/overviews/awp_india_v2.txt"  "file"
    "materials/overviews/awp_india_v2.vmt" "file"
    "materials/overviews/awp_india_v2.vtf" "file"
    "materials/overviews/awp_india_v2_radar.vmt"   "file"
    "maps/awp_india_v2.nav"    "file"
    "maps/awp_india_v2.bsp"    "file"
}