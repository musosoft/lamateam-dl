"resources"
{
    "resource/overviews/de_blitz_ukcs.txt"  "file"
    "materials/overviews/de_blitz_ukcs.vmt" "file"
    "materials/overviews/de_blitz_ukcs.vtf" "file"
    "materials/overviews/de_blitz_ukcs_radar.vmt"   "file"
    "maps/de_blitz_ukcs.nav"    "file"
    "maps/de_blitz_ukcs.bsp"    "file"
}