"resources"
{
    "resource/overviews/aim_deagle_ultra.txt"  "file"
    "materials/overviews/aim_deagle_ultra.vmt" "file"
    "materials/overviews/aim_deagle_ultra" "file"
    "materials/overviews/aim_deagle_ultra_radar.vmt"   "file"
    "maps/aim_deagle_ultra.nav"    "file"
    "maps/aim_deagle_ultra.bsp"    "file"
}